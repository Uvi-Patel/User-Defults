//
//  ViewController.swift
//  User Defults
//
//  Created by MAC on 07/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
           defaults.set(20, forKey: "age")
           defaults.set(true, forKey: "bool")
           defaults.set("happy", forKey: "name")
        
        let Age = defaults.integer(forKey: "age")
        print("\(Age)")
        
        let Bool = defaults.bool(forKey: "bool")
        print("\(Bool)")
        
        let Name = defaults.string(forKey: "name")!
        print("\(Name)")
  
        defaults.removeObject(forKey: "age")
        let Ageee = defaults.integer(forKey: "age")
        print("\(Ageee)")
    }
}

